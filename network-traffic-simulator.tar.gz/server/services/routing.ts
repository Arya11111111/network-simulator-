import { type Node, type Link } from "@shared/schema";

export class RoutingService {
  private nodes: Map<string, Node>;
  private links: Map<string, Link>;
  private adjacencyList: Map<string, string[]>;

  constructor() {
    this.nodes = new Map();
    this.links = new Map();
    this.adjacencyList = new Map();
  }

  updateTopology(nodes: Node[], links: Link[]) {
    this.nodes.clear();
    this.links.clear();
    this.adjacencyList.clear();

    // Build nodes map
    nodes.forEach(node => {
      this.nodes.set(node.id, node);
      this.adjacencyList.set(node.id, []);
    });

    // Build adjacency list from links
    links.forEach(link => {
      this.links.set(link.id, link);
      
      // Add bidirectional connections
      const fromNeighbors = this.adjacencyList.get(link.from) || [];
      const toNeighbors = this.adjacencyList.get(link.to) || [];
      
      fromNeighbors.push(link.to);
      toNeighbors.push(link.from);
      
      this.adjacencyList.set(link.from, fromNeighbors);
      this.adjacencyList.set(link.to, toNeighbors);
    });
  }

  // Dijkstra's shortest path algorithm
  findShortestPath(source: string, destination: string): string[] {
    if (source === destination) return [source];

    const distances = new Map<string, number>();
    const previous = new Map<string, string | null>();
    const unvisited = new Set<string>();

    // Initialize distances
    this.nodes.forEach((_, nodeId) => {
      distances.set(nodeId, nodeId === source ? 0 : Infinity);
      previous.set(nodeId, null);
      unvisited.add(nodeId);
    });

    while (unvisited.size > 0) {
      // Find unvisited node with minimum distance
      let current: string | null = null;
      let minDistance = Infinity;

      for (const nodeId of Array.from(unvisited)) {
        const distance = distances.get(nodeId) || Infinity;
        if (distance < minDistance) {
          minDistance = distance;
          current = nodeId;
        }
      }

      if (!current || minDistance === Infinity) break;

      unvisited.delete(current);

      if (current === destination) break;

      // Update distances to neighbors
      const neighbors = this.adjacencyList.get(current) || [];
      for (const neighbor of neighbors) {
        if (!unvisited.has(neighbor)) continue;

        // Calculate weight based on link load and capacity
        const linkId1 = `${current}-${neighbor}`;
        const linkId2 = `${neighbor}-${current}`;
        const link = this.links.get(linkId1) || this.links.get(linkId2);
        
        let weight = 1;
        if (link) {
          // Higher load means higher weight (less preferred path)
          weight = 1 + (link.loadPercentage / 100) * 5;
        }

        const currentDistance = distances.get(current) || 0;
        const newDistance = currentDistance + weight;
        const neighborDistance = distances.get(neighbor) || Infinity;

        if (newDistance < neighborDistance) {
          distances.set(neighbor, newDistance);
          previous.set(neighbor, current);
        }
      }
    }

    // Reconstruct path
    const path: string[] = [];
    let current: string | null = destination;

    while (current !== null) {
      path.unshift(current);
      current = previous.get(current) || null;
    }

    return path.length > 1 && path[0] === source ? path : [];
  }

  // Find all possible paths (for backup routing)
  findAllPaths(source: string, destination: string, maxHops: number = 5): string[][] {
    const paths: string[][] = [];
    const visited = new Set<string>();

    const dfs = (current: string, target: string, path: string[], hops: number) => {
      if (hops > maxHops) return;
      if (current === target) {
        paths.push([...path, current]);
        return;
      }

      visited.add(current);
      const neighbors = this.adjacencyList.get(current) || [];

      for (const neighbor of neighbors) {
        if (!visited.has(neighbor)) {
          dfs(neighbor, target, [...path, current], hops + 1);
        }
      }

      visited.delete(current);
    };

    dfs(source, destination, [], 0);
    return paths;
  }

  // Get next hop for a packet
  getNextHop(packetPath: string[], currentNode: string): string | null {
    const currentIndex = packetPath.indexOf(currentNode);
    if (currentIndex === -1 || currentIndex === packetPath.length - 1) {
      return null; // Packet has reached destination or invalid path
    }
    return packetPath[currentIndex + 1];
  }

  // Check if a link exists between two nodes
  hasLink(from: string, to: string): boolean {
    const linkId1 = `${from}-${to}`;
    const linkId2 = `${to}-${from}`;
    return this.links.has(linkId1) || this.links.has(linkId2);
  }

  // Get link between two nodes
  getLink(from: string, to: string): Link | null {
    const linkId1 = `${from}-${to}`;
    const linkId2 = `${to}-${from}`;
    return this.links.get(linkId1) || this.links.get(linkId2) || null;
  }
}
