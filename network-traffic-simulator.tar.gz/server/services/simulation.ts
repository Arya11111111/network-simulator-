import { type Node, type Link, type Packet, type SimulationState, type NetworkStats } from "@shared/schema";
import { storage } from "../storage";
import { RoutingService } from "./routing";

export class SimulationEngine {
  private routingService: RoutingService;
  private simulationTimer: NodeJS.Timeout | null = null;
  private packetGenerationTimer: NodeJS.Timeout | null = null;
  private startTime: number = 0;
  private packetCounter: number = 0;
  private latencySum: number = 0;
  private processedPackets: number = 0;

  constructor() {
    this.routingService = new RoutingService();
  }

  async initialize() {
    const nodes = await storage.getNodes();
    const links = await storage.getLinks();
    this.routingService.updateTopology(nodes, links);
  }

  async start() {
    await this.initialize();
    
    const state = await storage.getSimulationState();
    if (state.isRunning) return;

    this.startTime = Date.now();
    this.packetCounter = 0;
    this.latencySum = 0;
    this.processedPackets = 0;

    await storage.updateSimulationState({
      isRunning: true,
      isPaused: false,
      startTime: this.startTime,
    });

    this.startSimulationLoop();
    this.startPacketGeneration();
  }

  async pause() {
    const state = await storage.getSimulationState();
    if (!state.isRunning) return;

    await storage.updateSimulationState({
      isPaused: !state.isPaused,
    });

    if (state.isPaused) {
      this.startSimulationLoop();
      this.startPacketGeneration();
    } else {
      this.stopTimers();
    }
  }

  async stop() {
    this.stopTimers();
    await storage.clearPackets();
    await storage.updateSimulationState({
      isRunning: false,
      isPaused: false,
      elapsedTime: 0,
      totalPackets: 0,
      packetsProcessed: 0,
      packetsDropped: 0,
      avgLatency: 0,
      throughput: 0,
      packetLossRate: 0,
    });

    // Reset node queues
    const nodes = await storage.getNodes();
    for (const node of nodes) {
      await storage.updateNode(node.id, { queueSize: 0, status: 'active' });
    }

    // Reset link loads
    const links = await storage.getLinks();
    for (const link of links) {
      await storage.updateLink(link.id, { currentLoad: 0, loadPercentage: 0, status: 'active' });
    }
  }

  async updateTrafficMultiplier(multiplier: number) {
    await storage.updateSimulationState({ trafficMultiplier: multiplier });
  }

  async updateInterval(interval: number) {
    await storage.updateSimulationState({ updateInterval: interval });
    
    const state = await storage.getSimulationState();
    if (state.isRunning && !state.isPaused) {
      this.stopTimers();
      this.startSimulationLoop();
    }
  }

  private stopTimers() {
    if (this.simulationTimer) {
      clearInterval(this.simulationTimer);
      this.simulationTimer = null;
    }
    if (this.packetGenerationTimer) {
      clearInterval(this.packetGenerationTimer);
      this.packetGenerationTimer = null;
    }
  }

  private startSimulationLoop() {
    const runSimulationStep = async () => {
      const state = await storage.getSimulationState();
      if (!state.isRunning || state.isPaused) return;

      await this.simulationStep();
    };

    const state = storage.getSimulationState();
    state.then(s => {
      this.simulationTimer = setInterval(runSimulationStep, s.updateInterval);
    });
  }

  private startPacketGeneration() {
    const generatePackets = async () => {
      const state = await storage.getSimulationState();
      if (!state.isRunning || state.isPaused) return;

      await this.generatePackets();
    };

    // Generate packets every second
    this.packetGenerationTimer = setInterval(generatePackets, 1000);
  }

  private async generatePackets() {
    const nodes = await storage.getNodes();
    const state = await storage.getSimulationState();

    for (const node of nodes) {
      const packetsToGenerate = Math.floor(node.trafficRate * state.trafficMultiplier);
      
      for (let i = 0; i < packetsToGenerate; i++) {
        // Random destination (different from source)
        const possibleDestinations = nodes.filter(n => n.id !== node.id);
        const destination = possibleDestinations[Math.floor(Math.random() * possibleDestinations.length)];

        if (destination) {
          const path = this.routingService.findShortestPath(node.id, destination.id);
          
          if (path.length > 1) {
            await storage.addPacket({
              source: node.id,
              destination: destination.id,
              path,
              currentNode: node.id,
              timestamp: Date.now(),
              hopCount: 0,
            });

            this.packetCounter++;
          }
        }
      }
    }

    await storage.updateSimulationState({ totalPackets: this.packetCounter });
  }

  private async simulationStep() {
    // Update elapsed time
    const currentTime = Date.now();
    const elapsedTime = Math.floor((currentTime - this.startTime) / 1000);
    await storage.updateSimulationState({ elapsedTime });

    // Process packets
    await this.processPackets();
    
    // Update network statistics
    await this.updateNetworkStatistics();
    
    // Update node and link statuses
    await this.updateNetworkStatus();
  }

  private async processPackets() {
    const packets = await storage.getPackets();
    const nodes = await storage.getNodes();
    const links = await storage.getLinks();

    // Reset link loads
    const linkLoads = new Map<string, number>();
    
    for (const packet of packets) {
      const nextHop = this.routingService.getNextHop(packet.path, packet.currentNode);
      
      if (!nextHop) {
        // Packet reached destination
        this.processedPackets++;
        this.latencySum += Date.now() - packet.timestamp;
        await storage.removePacket(packet.id);
        continue;
      }

      // Check if link exists and has capacity
      const link = this.routingService.getLink(packet.currentNode, nextHop);
      if (!link) {
        // Drop packet - no route
        await storage.removePacket(packet.id);
        continue;
      }

      const linkId = link.id;
      const currentLinkLoad = linkLoads.get(linkId) || 0;
      
      // Check link capacity
      if (currentLinkLoad >= link.capacity) {
        // Queue packet at current node
        const currentNode = nodes.find(n => n.id === packet.currentNode);
        if (currentNode) {
          if (currentNode.queueSize >= currentNode.maxQueueSize) {
            // Drop packet - queue full
            await storage.removePacket(packet.id);
          } else {
            // Add to queue
            await storage.updateNode(currentNode.id, { queueSize: currentNode.queueSize + 1 });
          }
        }
      } else {
        // Move packet to next hop
        linkLoads.set(linkId, currentLinkLoad + 1);
        await storage.updatePacket(packet.id, {
          currentNode: nextHop,
          hopCount: packet.hopCount + 1,
        });

        // Reduce queue size if packet was queued
        const currentNode = nodes.find(n => n.id === packet.currentNode);
        if (currentNode && currentNode.queueSize > 0) {
          await storage.updateNode(currentNode.id, { queueSize: Math.max(0, currentNode.queueSize - 1) });
        }
      }
    }

    // Update link loads
    for (const link of links) {
      const load = linkLoads.get(link.id) || 0;
      const loadPercentage = Math.min(100, (load / link.capacity) * 100);
      await storage.updateLink(link.id, { currentLoad: load, loadPercentage });
    }
  }

  private async updateNetworkStatistics() {
    const state = await storage.getSimulationState();
    const packets = await storage.getPackets();
    
    const avgLatency = this.processedPackets > 0 ? this.latencySum / this.processedPackets : 0;
    const throughput = state.elapsedTime > 0 ? this.processedPackets / state.elapsedTime : 0;
    const packetLossRate = state.totalPackets > 0 ? 
      ((state.totalPackets - this.processedPackets - packets.length) / state.totalPackets) * 100 : 0;

    await storage.updateSimulationState({
      packetsProcessed: this.processedPackets,
      packetsDropped: state.totalPackets - this.processedPackets - packets.length,
      avgLatency,
      throughput,
      packetLossRate,
    });
  }

  private async updateNetworkStatus() {
    const nodes = await storage.getNodes();
    const links = await storage.getLinks();

    // Update node statuses based on queue size
    for (const node of nodes) {
      let status: 'active' | 'congested' | 'overloaded' = 'active';
      const queuePercent = (node.queueSize / node.maxQueueSize) * 100;
      
      if (queuePercent >= 80) status = 'overloaded';
      else if (queuePercent >= 50) status = 'congested';
      
      await storage.updateNode(node.id, { status });
    }

    // Update link statuses based on load
    for (const link of links) {
      let status: 'active' | 'congested' | 'overloaded' = 'active';
      
      if (link.loadPercentage >= 95) status = 'overloaded';
      else if (link.loadPercentage >= 80) status = 'congested';
      
      await storage.updateLink(link.id, { status });
    }
  }

  async getNetworkStats(): Promise<NetworkStats> {
    return await storage.getNetworkStats();
  }
}

export const simulationEngine = new SimulationEngine();
