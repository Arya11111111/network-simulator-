import { type Node, type Link, type Packet, type SimulationState, type NetworkStats } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Network topology
  getNodes(): Promise<Node[]>;
  getLinks(): Promise<Link[]>;
  updateNode(nodeId: string, updates: Partial<Node>): Promise<Node>;
  updateLink(linkId: string, updates: Partial<Link>): Promise<Link>;
  
  // Packets
  getPackets(): Promise<Packet[]>;
  addPacket(packet: Omit<Packet, 'id'>): Promise<Packet>;
  updatePacket(packetId: string, updates: Partial<Packet>): Promise<Packet>;
  removePacket(packetId: string): Promise<void>;
  clearPackets(): Promise<void>;
  
  // Simulation state
  getSimulationState(): Promise<SimulationState>;
  updateSimulationState(updates: Partial<SimulationState>): Promise<SimulationState>;
  
  // Network stats
  getNetworkStats(): Promise<NetworkStats>;
}

export class MemStorage implements IStorage {
  private nodes: Map<string, Node>;
  private links: Map<string, Link>;
  private packets: Map<string, Packet>;
  private simulationState: SimulationState;

  constructor() {
    this.nodes = new Map();
    this.links = new Map();
    this.packets = new Map();
    
    // Initialize simulation state
    this.simulationState = {
      isRunning: false,
      isPaused: false,
      elapsedTime: 0,
      totalPackets: 0,
      packetsProcessed: 0,
      packetsDropped: 0,
      avgLatency: 0,
      throughput: 0,
      packetLossRate: 0,
      trafficMultiplier: 1.0,
      updateInterval: 500,
    };

    // Initialize network topology with 5 nodes (A, B, C, D, E)
    this.initializeNetwork();
  }

  private initializeNetwork() {
    // Initialize nodes
    const nodePositions = {
      A: { x: 150, y: 100 },
      B: { x: 350, y: 100 },
      C: { x: 150, y: 300 },
      D: { x: 550, y: 200 },
      E: { x: 650, y: 300 },
    };

    Object.entries(nodePositions).forEach(([id, pos]) => {
      this.nodes.set(id, {
        id,
        name: `Router ${id}`,
        x: pos.x,
        y: pos.y,
        trafficRate: Math.floor(Math.random() * 50) + 20, // 20-70 pps
        queueSize: 0,
        maxQueueSize: 50,
        status: 'active',
      });
    });

    // Initialize links with capacities
    const linkDefinitions = [
      { from: 'A', to: 'B', capacity: 100 },
      { from: 'A', to: 'C', capacity: 80 },
      { from: 'B', to: 'D', capacity: 120 },
      { from: 'C', to: 'D', capacity: 90 },
      { from: 'C', to: 'E', capacity: 110 },
      { from: 'D', to: 'E', capacity: 60 },
    ];

    linkDefinitions.forEach(linkDef => {
      const linkId = `${linkDef.from}-${linkDef.to}`;
      this.links.set(linkId, {
        id: linkId,
        from: linkDef.from,
        to: linkDef.to,
        capacity: linkDef.capacity,
        currentLoad: 0,
        loadPercentage: 0,
        status: 'active',
      });
    });
  }

  async getNodes(): Promise<Node[]> {
    return Array.from(this.nodes.values());
  }

  async getLinks(): Promise<Link[]> {
    return Array.from(this.links.values());
  }

  async updateNode(nodeId: string, updates: Partial<Node>): Promise<Node> {
    const node = this.nodes.get(nodeId);
    if (!node) throw new Error(`Node ${nodeId} not found`);
    
    const updatedNode = { ...node, ...updates };
    this.nodes.set(nodeId, updatedNode);
    return updatedNode;
  }

  async updateLink(linkId: string, updates: Partial<Link>): Promise<Link> {
    const link = this.links.get(linkId);
    if (!link) throw new Error(`Link ${linkId} not found`);
    
    const updatedLink = { ...link, ...updates };
    this.links.set(linkId, updatedLink);
    return updatedLink;
  }

  async getPackets(): Promise<Packet[]> {
    return Array.from(this.packets.values());
  }

  async addPacket(packet: Omit<Packet, 'id'>): Promise<Packet> {
    const id = randomUUID();
    const newPacket: Packet = { ...packet, id };
    this.packets.set(id, newPacket);
    return newPacket;
  }

  async updatePacket(packetId: string, updates: Partial<Packet>): Promise<Packet> {
    const packet = this.packets.get(packetId);
    if (!packet) throw new Error(`Packet ${packetId} not found`);
    
    const updatedPacket = { ...packet, ...updates };
    this.packets.set(packetId, updatedPacket);
    return updatedPacket;
  }

  async removePacket(packetId: string): Promise<void> {
    this.packets.delete(packetId);
  }

  async clearPackets(): Promise<void> {
    this.packets.clear();
  }

  async getSimulationState(): Promise<SimulationState> {
    return this.simulationState;
  }

  async updateSimulationState(updates: Partial<SimulationState>): Promise<SimulationState> {
    this.simulationState = { ...this.simulationState, ...updates };
    return this.simulationState;
  }

  async getNetworkStats(): Promise<NetworkStats> {
    return {
      nodes: await this.getNodes(),
      links: await this.getLinks(),
      simulation: await this.getSimulationState(),
      packets: await this.getPackets(),
    };
  }
}

export const storage = new MemStorage();
