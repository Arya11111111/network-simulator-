import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { simulationEngine } from "./services/simulation";
import { simulationControlSchema, wsMessageSchema } from "@shared/schema";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // REST API Routes
  app.get("/api/network-stats", async (req, res) => {
    try {
      const stats = await simulationEngine.getNetworkStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to get network statistics" });
    }
  });

  app.post("/api/simulation/control", async (req, res) => {
    try {
      const control = simulationControlSchema.parse(req.body);
      
      switch (control.action) {
        case 'start':
          await simulationEngine.start();
          break;
        case 'pause':
          await simulationEngine.pause();
          break;
        case 'reset':
          await simulationEngine.stop();
          break;
        case 'updateTrafficMultiplier':
          if (typeof control.payload === 'number') {
            await simulationEngine.updateTrafficMultiplier(control.payload);
          }
          break;
        case 'updateInterval':
          if (typeof control.payload === 'number') {
            await simulationEngine.updateInterval(control.payload);
          }
          break;
        default:
          return res.status(400).json({ error: "Unknown control action" });
      }

      const stats = await simulationEngine.getNetworkStats();
      res.json(stats);
    } catch (error) {
      res.status(400).json({ error: "Invalid control command" });
    }
  });

  // WebSocket Server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  const connectedClients = new Set<WebSocket>();

  wss.on('connection', (ws) => {
    console.log('WebSocket client connected');
    connectedClients.add(ws);

    // Send initial network stats
    simulationEngine.getNetworkStats().then(stats => {
      if (ws.readyState === WebSocket.OPEN) {
        const message = {
          type: 'networkUpdate' as const,
          data: stats,
          timestamp: Date.now(),
        };
        ws.send(JSON.stringify(message));
      }
    });

    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        if (message.type === 'simulationControl') {
          const control = simulationControlSchema.parse(message.data);
          
          switch (control.action) {
            case 'start':
              await simulationEngine.start();
              break;
            case 'pause':
              await simulationEngine.pause();
              break;
            case 'reset':
              await simulationEngine.stop();
              break;
            case 'updateTrafficMultiplier':
              if (typeof control.payload === 'number') {
                await simulationEngine.updateTrafficMultiplier(control.payload);
              }
              break;
            case 'updateInterval':
              if (typeof control.payload === 'number') {
                await simulationEngine.updateInterval(control.payload);
              }
              break;
          }

          // Broadcast updated stats to all clients
          const stats = await simulationEngine.getNetworkStats();
          broadcastToClients({
            type: 'networkUpdate',
            data: stats,
            timestamp: Date.now(),
          });
        }
      } catch (error) {
        ws.send(JSON.stringify({
          type: 'error',
          data: { message: 'Invalid message format' },
          timestamp: Date.now(),
        }));
      }
    });

    ws.on('close', () => {
      console.log('WebSocket client disconnected');
      connectedClients.delete(ws);
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      connectedClients.delete(ws);
    });
  });

  // Broadcast function for real-time updates
  function broadcastToClients(message: any) {
    const messageStr = JSON.stringify(message);
    connectedClients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(messageStr);
      }
    });
  }

  // Periodic broadcast of network stats during simulation
  setInterval(async () => {
    try {
      const state = await storage.getSimulationState();
      if (state.isRunning && !state.isPaused && connectedClients.size > 0) {
        const stats = await simulationEngine.getNetworkStats();
        broadcastToClients({
          type: 'networkUpdate',
          data: stats,
          timestamp: Date.now(),
        });
      }
    } catch (error) {
      console.error('Error broadcasting network stats:', error);
    }
  }, 1000); // Broadcast every second

  return httpServer;
}
