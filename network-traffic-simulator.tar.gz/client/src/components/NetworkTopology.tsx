import { type NetworkStats } from '@shared/schema';
import { useState } from 'react';

interface NetworkTopologyProps {
  networkStats: NetworkStats | null;
}

export function NetworkTopology({ networkStats }: NetworkTopologyProps) {
  const [selectedNode, setSelectedNode] = useState<string | null>(null);

  if (!networkStats) {
    return (
      <div className="w-full h-96 bg-gray-50 rounded-lg border border-gray-200 flex items-center justify-center">
        <div className="text-gray-500">Loading network topology...</div>
      </div>
    );
  }

  const { nodes, links } = networkStats;

  const getNodeStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'hsl(123, 43%, 55%)'; // success green
      case 'congested': return 'hsl(45, 100%, 51%)'; // warning yellow
      case 'overloaded': return 'hsl(0, 84%, 60%)'; // error red
      default: return 'hsl(207, 90%, 54%)'; // primary blue
    }
  };

  const getLinkStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'hsl(188, 100%, 38%)'; // secondary cyan
      case 'congested': return 'hsl(45, 100%, 51%)'; // warning yellow
      case 'overloaded': return 'hsl(0, 84%, 60%)'; // error red
      default: return 'hsl(188, 100%, 38%)';
    }
  };

  const getLinkWidth = (loadPercentage: number) => {
    return Math.max(2, Math.min(6, 2 + (loadPercentage / 100) * 4));
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-gray-900">Network Topology</h2>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: 'hsl(123, 43%, 55%)' }}></div>
            <span className="text-sm text-gray-600">Active</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: 'hsl(45, 100%, 51%)' }}></div>
            <span className="text-sm text-gray-600">Congested</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: 'hsl(0, 84%, 60%)' }}></div>
            <span className="text-sm text-gray-600">Overloaded</span>
          </div>
        </div>
      </div>
      
      <div className="relative w-full h-96 bg-gray-50 rounded-lg border border-gray-200 overflow-hidden">
        <svg viewBox="0 0 800 400" className="w-full h-full">
          <defs>
            <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
              <polygon points="0 0, 10 3.5, 0 7" fill="hsl(188, 100%, 38%)" />
            </marker>
          </defs>
          
          {/* Render Links */}
          {links.map((link) => {
            const fromNode = nodes.find(n => n.id === link.from);
            const toNode = nodes.find(n => n.id === link.to);
            
            if (!fromNode || !toNode) return null;
            
            const strokeColor = getLinkStatusColor(link.status);
            const strokeWidth = getLinkWidth(link.loadPercentage);
            const isAnimated = link.loadPercentage > 50;
            
            // Calculate midpoint for label
            const midX = (fromNode.x + toNode.x) / 2;
            const midY = (fromNode.y + toNode.y) / 2;
            
            return (
              <g key={link.id}>
                <line
                  data-testid={`link-${link.id}`}
                  x1={fromNode.x}
                  y1={fromNode.y}
                  x2={toNode.x}
                  y2={toNode.y}
                  stroke={strokeColor}
                  strokeWidth={strokeWidth}
                  className={isAnimated ? "connection-line animated" : "connection-line"}
                  markerEnd="url(#arrowhead)"
                />
                <text
                  x={midX}
                  y={midY - 10}
                  textAnchor="middle"
                  className="text-xs fill-gray-600 font-medium"
                >
                  {Math.round(link.loadPercentage)}% Load
                </text>
              </g>
            );
          })}
          
          {/* Render Nodes */}
          {nodes.map((node) => {
            const isSelected = selectedNode === node.id;
            const statusColor = getNodeStatusColor(node.status);
            const queuePercentage = (node.queueSize / node.maxQueueSize) * 100;
            
            return (
              <g
                key={node.id}
                data-testid={`node-${node.id}`}
                className="network-node cursor-pointer"
                onClick={() => setSelectedNode(isSelected ? null : node.id)}
              >
                <circle
                  cx={node.x}
                  cy={node.y}
                  r={isSelected ? 28 : 25}
                  fill="hsl(207, 90%, 54%)"
                  stroke="#ffffff"
                  strokeWidth="3"
                  className="transition-all duration-200"
                />
                <text
                  x={node.x}
                  y={node.y + 5}
                  textAnchor="middle"
                  className="text-white font-semibold text-sm pointer-events-none"
                >
                  {node.id}
                </text>
                <circle
                  cx={node.x - 10}
                  cy={node.y - 10}
                  r="4"
                  fill={statusColor}
                  className={queuePercentage > 50 ? "pulse-animation" : ""}
                />
                
                {/* Node labels */}
                <text
                  x={node.x}
                  y={node.y + 45}
                  textAnchor="middle"
                  className="text-xs text-gray-700 font-medium pointer-events-none"
                >
                  {node.name}
                </text>
                <text
                  x={node.x}
                  y={node.y + 60}
                  textAnchor="middle"
                  className="text-xs text-gray-500 pointer-events-none"
                >
                  Queue: {node.queueSize}
                </text>
                
                {/* Show detailed info when selected */}
                {isSelected && (
                  <g>
                    <rect
                      x={node.x + 40}
                      y={node.y - 30}
                      width="120"
                      height="60"
                      fill="white"
                      stroke="hsl(20, 5.9%, 90%)"
                      rx="4"
                      className="drop-shadow-lg"
                    />
                    <text x={node.x + 50} y={node.y - 15} className="text-xs font-medium fill-gray-900">
                      Traffic: {node.trafficRate} pps
                    </text>
                    <text x={node.x + 50} y={node.y - 5} className="text-xs fill-gray-600">
                      Queue: {node.queueSize}/{node.maxQueueSize}
                    </text>
                    <text x={node.x + 50} y={node.y + 5} className="text-xs fill-gray-600">
                      Status: {node.status}
                    </text>
                    <text x={node.x + 50} y={node.y + 15} className="text-xs fill-gray-600">
                      Load: {Math.round(queuePercentage)}%
                    </text>
                  </g>
                )}
              </g>
            );
          })}
        </svg>
      </div>
      
      <div className="mt-4 grid grid-cols-2 md:grid-cols-5 gap-4">
        {nodes.map((node) => (
          <div key={node.id} className="bg-gray-50 rounded-lg p-3 text-center">
            <div className="text-sm font-medium text-gray-900">Node {node.id}</div>
            <div className="text-xs text-gray-500 mt-1">
              Traffic: <span className="font-medium" data-testid={`node-traffic-${node.id}`}>{node.trafficRate} pps</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
