import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Play, Pause, Square, Download } from 'lucide-react';
import { type NetworkStats, type SimulationControl } from '@shared/schema';
import { useState } from 'react';

interface SimulationControlsProps {
  networkStats: NetworkStats | null;
  isConnected: boolean;
  onSendControl: (control: SimulationControl) => void;
}

export function SimulationControls({ networkStats, isConnected, onSendControl }: SimulationControlsProps) {
  const [trafficMultiplier, setTrafficMultiplier] = useState(1.0);
  const [updateInterval, setUpdateInterval] = useState(500);

  const handleStart = () => {
    onSendControl({ action: 'start' });
  };

  const handlePause = () => {
    onSendControl({ action: 'pause' });
  };

  const handleReset = () => {
    onSendControl({ action: 'reset' });
  };

  const handleTrafficMultiplierChange = (value: number[]) => {
    const newMultiplier = value[0];
    setTrafficMultiplier(newMultiplier);
    onSendControl({ action: 'updateTrafficMultiplier', payload: newMultiplier });
  };

  const handleIntervalChange = (value: string) => {
    const newInterval = parseInt(value);
    setUpdateInterval(newInterval);
    onSendControl({ action: 'updateInterval', payload: newInterval });
  };

  const handleExportData = () => {
    if (!networkStats) return;
    
    const data = {
      timestamp: new Date().toISOString(),
      simulation: networkStats.simulation,
      nodes: networkStats.nodes,
      links: networkStats.links,
      packets: networkStats.packets,
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `network-simulation-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getStatusColor = () => {
    if (!isConnected) return 'hsl(0, 84%, 60%)'; // error red
    if (!networkStats?.simulation.isRunning) return 'hsl(25, 5.3%, 44.7%)'; // muted gray
    if (networkStats.simulation.isPaused) return 'hsl(45, 100%, 51%)'; // warning yellow
    return 'hsl(123, 43%, 55%)'; // success green
  };

  const getStatusText = () => {
    if (!isConnected) return 'Disconnected';
    if (!networkStats?.simulation.isRunning) return 'Stopped';
    if (networkStats.simulation.isPaused) return 'Paused';
    return 'Running';
  };

  return (
    <div className="space-y-6">
      {/* Simulation Controls Header */}
      <Card className="stats-card">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg font-semibold text-gray-900">Simulation Controls</CardTitle>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-500">Status:</span>
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium text-white" style={{ backgroundColor: getStatusColor() }}>
              <div className="w-2 h-2 rounded-full bg-white mr-1 pulse-animation"></div>
              {getStatusText()}
            </span>
          </div>
          {networkStats?.simulation.isRunning && (
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-500">Simulation Time:</span>
              <span className="font-mono text-sm font-medium text-gray-900" data-testid="simulation-time">
                {formatTime(networkStats.simulation.elapsedTime)}
              </span>
            </div>
          )}
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex space-x-3">
            <Button
              onClick={handleStart}
              disabled={!isConnected || (networkStats?.simulation.isRunning && !networkStats?.simulation.isPaused)}
              className="bg-green-600 hover:bg-green-700 text-white"
              data-testid="button-start"
            >
              <Play className="w-4 h-4 mr-2" />
              Start
            </Button>
            <Button
              onClick={handlePause}
              disabled={!isConnected || !networkStats?.simulation.isRunning}
              className="bg-yellow-600 hover:bg-yellow-700 text-white"
              data-testid="button-pause"
            >
              <Pause className="w-4 h-4 mr-2" />
              {networkStats?.simulation.isPaused ? 'Resume' : 'Pause'}
            </Button>
            <Button
              onClick={handleReset}
              disabled={!isConnected}
              variant="destructive"
              data-testid="button-reset"
            >
              <Square className="w-4 h-4 mr-2" />
              Reset
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Simulation Parameters */}
      <Card className="stats-card">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg font-semibold text-gray-900">Simulation Parameters</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Traffic Rate Multiplier
            </label>
            <Slider
              value={[trafficMultiplier]}
              onValueChange={handleTrafficMultiplierChange}
              min={0.1}
              max={3.0}
              step={0.1}
              className="w-full"
              disabled={!isConnected}
              data-testid="slider-traffic-multiplier"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>0.1x</span>
              <span data-testid="text-multiplier">{trafficMultiplier.toFixed(1)}x</span>
              <span>3.0x</span>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Update Interval
            </label>
            <Select value={updateInterval.toString()} onValueChange={handleIntervalChange} disabled={!isConnected}>
              <SelectTrigger className="w-full" data-testid="select-update-interval">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="100">100ms</SelectItem>
                <SelectItem value="500">500ms</SelectItem>
                <SelectItem value="1000">1000ms</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="pt-2">
            <Button
              onClick={handleExportData}
              disabled={!networkStats}
              className="w-full bg-cyan-600 hover:bg-cyan-700 text-white"
              data-testid="button-export"
            >
              <Download className="w-4 h-4 mr-2" />
              Export Data
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
