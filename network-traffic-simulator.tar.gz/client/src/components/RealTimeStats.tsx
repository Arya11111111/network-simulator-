import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { type NetworkStats } from '@shared/schema';

interface RealTimeStatsProps {
  networkStats: NetworkStats | null;
}

export function RealTimeStats({ networkStats }: RealTimeStatsProps) {
  if (!networkStats) {
    return (
      <div className="space-y-6">
        <Card className="stats-card">
          <CardContent className="pt-6">
            <div className="text-center text-gray-500">Loading statistics...</div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { nodes, links, simulation } = networkStats;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'hsl(123, 43%, 55%)';
      case 'congested': return 'hsl(45, 100%, 51%)';
      case 'overloaded': return 'hsl(0, 84%, 60%)';
      default: return 'hsl(25, 5.3%, 44.7%)';
    }
  };

  const getQueueColor = (percentage: number) => {
    if (percentage >= 80) return 'hsl(0, 84%, 60%)'; // error
    if (percentage >= 50) return 'hsl(45, 100%, 51%)'; // warning
    return 'hsl(123, 43%, 55%)'; // success
  };

  return (
    <div className="space-y-6">
      {/* Overall Network Stats */}
      <Card className="stats-card">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg font-semibold text-gray-900">Network Overview</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Total Packets</span>
            <span className="font-semibold text-gray-900" data-testid="text-total-packets">
              {simulation.totalPackets.toLocaleString()}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Avg Latency</span>
            <span className="font-semibold text-gray-900" data-testid="text-avg-latency">
              {simulation.avgLatency.toFixed(1)}ms
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Throughput</span>
            <span className="font-semibold text-gray-900" data-testid="text-throughput">
              {Math.round(simulation.throughput)} pps
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Packet Loss</span>
            <span className="font-semibold text-red-600" data-testid="text-packet-loss">
              {simulation.packetLossRate.toFixed(1)}%
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Active Connections */}
      <Card className="stats-card">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg font-semibold text-gray-900">Link Status</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {links.map((link) => (
            <div key={link.id} className="flex items-center justify-between p-2 rounded-lg bg-gray-50">
              <div className="flex items-center space-x-2">
                <div 
                  className="w-2 h-2 rounded-full" 
                  style={{ backgroundColor: getStatusColor(link.status) }}
                />
                <span className="text-sm font-medium text-gray-900" data-testid={`link-status-${link.id}`}>
                  {link.from} → {link.to}
                </span>
              </div>
              <span className="text-xs text-gray-600" data-testid={`link-load-${link.id}`}>
                {Math.round(link.loadPercentage)}%
              </span>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Queue Status */}
      <Card className="stats-card">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg font-semibold text-gray-900">Queue Status</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {nodes.map((node) => {
            const queuePercentage = (node.queueSize / node.maxQueueSize) * 100;
            const color = getQueueColor(queuePercentage);
            
            return (
              <div key={node.id}>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm text-gray-600">Node {node.id}</span>
                  <span className="text-sm font-medium text-gray-900" data-testid={`node-queue-${node.id}`}>
                    {node.queueSize}
                  </span>
                </div>
                <Progress 
                  value={queuePercentage} 
                  className="w-full h-2"
                  style={{ 
                    backgroundColor: 'hsl(20, 5.9%, 90%)',
                  }}
                  data-testid={`progress-queue-${node.id}`}
                />

              </div>
            );
          })}
        </CardContent>
      </Card>

      {/* Performance Metrics */}
      <Card className="stats-card">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg font-semibold text-gray-900">Performance Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg">
              <div className="text-2xl font-bold text-blue-600" data-testid="metric-packets-processed">
                {simulation.packetsProcessed.toLocaleString()}
              </div>
              <div className="text-sm text-gray-600 mt-1">Packets Processed</div>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-lg">
              <div className="text-2xl font-bold text-green-600" data-testid="metric-throughput">
                {Math.round(simulation.throughput)}
              </div>
              <div className="text-sm text-gray-600 mt-1">Avg Throughput (pps)</div>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-lg">
              <div className="text-2xl font-bold text-yellow-600" data-testid="metric-latency">
                {simulation.avgLatency.toFixed(1)}
              </div>
              <div className="text-sm text-gray-600 mt-1">Avg Latency (ms)</div>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-red-50 to-red-100 rounded-lg">
              <div className="text-2xl font-bold text-red-600" data-testid="metric-packet-loss">
                {simulation.packetLossRate.toFixed(1)}%
              </div>
              <div className="text-sm text-gray-600 mt-1">Packet Loss Rate</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
