import { NetworkTopology } from '@/components/NetworkTopology';
import { RealTimeStats } from '@/components/RealTimeStats';
import { SimulationControls } from '@/components/SimulationControls';
import { useWebSocket } from '@/hooks/useWebSocket';
import { AlertCircle, Wifi, WifiOff } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

export default function Dashboard() {
  const { networkStats, isConnected, error, sendControl } = useWebSocket();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <i className="fas fa-network-wired text-blue-600 text-xl"></i>
                <h1 className="text-xl font-semibold text-gray-900">Network Traffic Simulator</h1>
              </div>
              <div className="hidden sm:flex items-center space-x-2">
                <span className="text-sm text-gray-500">Connection:</span>
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                  isConnected 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-red-100 text-red-800'
                }`}>
                  {isConnected ? (
                    <>
                      <Wifi className="w-3 h-3 mr-1" />
                      Connected
                    </>
                  ) : (
                    <>
                      <WifiOff className="w-3 h-3 mr-1" />
                      Disconnected
                    </>
                  )}
                </span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Error Alert */}
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Network Topology - Main Area */}
          <div className="lg:col-span-3">
            <NetworkTopology networkStats={networkStats} />
          </div>
          
          {/* Right Sidebar - Stats and Controls */}
          <div className="lg:col-span-1 space-y-6">
            <SimulationControls 
              networkStats={networkStats}
              isConnected={isConnected}
              onSendControl={sendControl}
            />
            <RealTimeStats networkStats={networkStats} />
          </div>
        </div>
      </main>
    </div>
  );
}
