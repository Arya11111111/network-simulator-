import { z } from "zod";

// Network Node Schema
export const nodeSchema = z.object({
  id: z.string(),
  name: z.string(),
  x: z.number(),
  y: z.number(),
  trafficRate: z.number(), // packets per second generated
  queueSize: z.number(),
  maxQueueSize: z.number(),
  status: z.enum(['active', 'congested', 'overloaded']),
});

// Network Link Schema
export const linkSchema = z.object({
  id: z.string(),
  from: z.string(),
  to: z.string(),
  capacity: z.number(), // max packets per second
  currentLoad: z.number(),
  loadPercentage: z.number(),
  status: z.enum(['active', 'congested', 'overloaded']),
});

// Packet Schema
export const packetSchema = z.object({
  id: z.string(),
  source: z.string(),
  destination: z.string(),
  path: z.array(z.string()),
  currentNode: z.string(),
  timestamp: z.number(),
  hopCount: z.number(),
});

// Simulation State Schema
export const simulationStateSchema = z.object({
  isRunning: z.boolean(),
  isPaused: z.boolean(),
  startTime: z.number().optional(),
  elapsedTime: z.number(),
  totalPackets: z.number(),
  packetsProcessed: z.number(),
  packetsDropped: z.number(),
  avgLatency: z.number(),
  throughput: z.number(),
  packetLossRate: z.number(),
  trafficMultiplier: z.number(),
  updateInterval: z.number(),
});

// Network Statistics Schema
export const networkStatsSchema = z.object({
  nodes: z.array(nodeSchema),
  links: z.array(linkSchema),
  simulation: simulationStateSchema,
  packets: z.array(packetSchema),
});

// WebSocket Message Schema
export const wsMessageSchema = z.object({
  type: z.enum(['networkUpdate', 'simulationControl', 'error']),
  data: z.any(),
  timestamp: z.number(),
});

// Simulation Control Schema
export const simulationControlSchema = z.object({
  action: z.enum(['start', 'pause', 'reset', 'updateTrafficMultiplier', 'updateInterval']),
  payload: z.any().optional(),
});

// Export types
export type Node = z.infer<typeof nodeSchema>;
export type Link = z.infer<typeof linkSchema>;
export type Packet = z.infer<typeof packetSchema>;
export type SimulationState = z.infer<typeof simulationStateSchema>;
export type NetworkStats = z.infer<typeof networkStatsSchema>;
export type WSMessage = z.infer<typeof wsMessageSchema>;
export type SimulationControl = z.infer<typeof simulationControlSchema>;
